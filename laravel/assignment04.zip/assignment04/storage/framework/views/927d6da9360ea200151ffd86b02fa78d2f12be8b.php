
<?php $__env->startSection('content'); ?>

<h1 class="display-6 text-center mb-4">Laravel Crud with Ajax</h1>
<a class="btn btn-primary my-4" href="/posts-create" role="button">Create New Post</a>
<table class="table">
  <thead class="text-center">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Title</th>
      <th scope="col">Content</th>
      <th scope="col">Author</th>
      <th scope="col">Email</th>
      <th scope="col">Phone</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
<script src="<?php echo e(js/showList.js); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('API.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\php_training\laravel\assignment04\resources\views/API/api-index.blade.php ENDPATH**/ ?>