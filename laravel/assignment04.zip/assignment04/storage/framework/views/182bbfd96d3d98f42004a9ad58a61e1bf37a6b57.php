
<?php $__env->startSection('content'); ?>

<div class="card">
  <div class="card-header">Contactus Page</div>
  <div class="card-body">
    <?php if(count($errors) > 0): ?>
    <!-- Form Error List -->
    <div class="alert alert-danger text-center">
      <strong class="text-red-700 text-opacity-100">Whoops...Something Wrong</strong>
      <br><br>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="text-red-700 text-opacity-100 mb-2"><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(url('/users')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <label>Author</label></br>
      <input type="text" name="name" id="name" class="form-control"></br>
      <label>Gender</label></br>
      <input type="text" name="gender" id="gender" class="form-control"></br>
      <label>Address</label></br>
      <input type="text" name="address" id="address" class="form-control"></br>
      <label>Email</label></br>
      <input type="email" name="email" id="email" class="form-control"></br>
      <label>Phone</label></br>
      <input type="text" name="phone" id="phone" class="form-control"></br>
      <label>Password</label></br>
      <input type="password" name="password" id="password" class="form-control"></br>
      <input type="submit" value="Save" class="btn btn-primary"></br>
    </form>

  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\php_training\laravel\assignment03\resources\views/users/create.blade.php ENDPATH**/ ?>