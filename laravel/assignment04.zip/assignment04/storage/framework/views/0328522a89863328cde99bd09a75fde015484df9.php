

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">

    <div class="col-md-9">
      <div class="card">
        <div class="card-header text-dark">Users</div>
        <div class="card-body">
          <a href="<?php echo e(url('/users/create')); ?>" class="btn btn-success btn-sm" title="Add New Contact">
            <i class="fa fa-plus" aria-hidden="true"></i> Add New
          </a>
          <a href="<?php echo e(route('index')); ?>" class="btn btn-info btn-sm">
            <i class="far fa-arrow-alt-circle-left"></i> To Posts List
          </a>
          <br>
          <br>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Author</th>
                  <th>Gender</th>
                  <th>Address</th>
                  <th>Email</th>
                  <th>Phone Number</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($user->author); ?></td>
                  <td><?php echo e($user->gender); ?></td>
                  <td><?php echo e($user->address); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td><?php echo e($user->phone); ?></td>
                  <td>

                    <a href="<?php echo e(route('user.edit',$user->id)); ?>" title="Edit Student"><button class="btn"><i class="fas fa-edit text-warning"></i></button></a>

                    <form method="POST" action="<?php echo e(route('user.destroy',$user->id)); ?>" accept-charset="UTF-8" style="display:inline">
                      <?php echo e(method_field('DELETE')); ?>

                      <?php echo e(csrf_field()); ?>

                      <button type="submit" class="btn" title="Delete Contact" onclick="return confirm('Are you sure?')"><i class="fas fa-trash-alt text-danger"></i></button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Apache24\htdocs\php_training\laravel\assignment03\resources\views/users/index-user.blade.php ENDPATH**/ ?>